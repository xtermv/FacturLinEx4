MANUAL WEB DE FACTURLINEX - EDICIÓN v0.6
================================================

CONTENIDO
---------
- Manual web estático y responsive.
- Buscador instantáneo y navegación por capítulos.
- Modo claro/oscuro.
- Capítulos ilustrados: Menú, Configuración, Clientes, Artículos y Ventas.
- Descargas integradas en DOCX y PDF.

INSTALACIÓN
-----------
Descomprima y copie la carpeta en, por ejemplo:

   /var/www/html/manual-facturlinex/

Después abra https://su-dominio/manual-facturlinex/
No necesita PHP ni MariaDB y también funciona abriendo index.html localmente.

ARCHIVOS DE DESCARGA
--------------------
- descargas/Manual_FacturLinEx_v0.6_Articulos_Ilustrado.pdf
- descargas/Manual_FacturLinEx_v0.6_Articulos_Ilustrado.docx

NOVEDAD v0.6
------------
Artículos, familias y tarifas incorpora ficha general, costes, tarifas, EAN, puntos, actualización masiva de precios y stock. Las reconstrucciones documentales y las capturas reales están identificadas. Toda leyenda numerada del capítulo conserva cuadros y números visibles.

REVISIÓN FINAL PENDIENTE
------------------------
Al terminar todos los capítulos se revisará el manual completo imagen por imagen, especialmente Ventas, para comprobar que cada número referencia un cuadro visible y una leyenda correcta.
