MANUAL WEB DE FACTURLINEX - EDICIÓN v1.0
================================================

CONTENIDO
---------
- Manual web estático, responsive y con buscador.
- Modo claro/oscuro.
- Capítulos ilustrados del 1 al 9.
- Descargas integradas en DOCX y PDF.

INSTALACIÓN
-----------
Copie la carpeta en su servidor web y abra index.html. No necesita PHP ni MariaDB.

ARCHIVOS
--------
- descargas/Manual_FacturLinEx_v1.0_Verifactu_Rectificativas_Ilustrado.pdf
- descargas/Manual_FacturLinEx_v1.0_Verifactu_Rectificativas_Ilustrado.docx

NOVEDAD v1.0
------------
VeriFactu y rectificativas incorpora F1/F2, R1/R5, cola, monitor, estados internos, respuestas AEAT, cadenas de hash, incidencias y trazabilidad rectificativa.

CRITERIO VISUAL
---------------
Todas las figuras nuevas con leyendas numeradas conservan cuadros y números visibles.

REVISIÓN FINAL PENDIENTE
------------------------
Al terminar Dashboard y mantenimiento se auditarán todas las imágenes, especialmente Ventas.
