MANUAL WEB DE FACTURLINEX - EDICIÓN v1.1
================================================

CONTENIDO
---------
- Manual web estático, responsive y con buscador.
- Modo claro/oscuro.
- Capítulos ilustrados del 1 al 10.
- Descargas integradas en DOCX y PDF.

INSTALACIÓN
-----------
Copie la carpeta en su servidor web y abra index.html. No necesita PHP ni MariaDB.

ARCHIVOS
--------
- descargas/Manual_FacturLinEx_v1.1_Dashboard_Consultas_Estadisticas_Ilustrado.pdf
- descargas/Manual_FacturLinEx_v1.1_Dashboard_Consultas_Estadisticas_Ilustrado.docx

NOVEDAD v1.1
------------
Dashboard, consultas y estadísticas incorpora gráficos con valores visibles, período Hoy por defecto, consulta SELECT, calidad del precio tras descuentos y exportación revisada.

CRITERIO VISUAL
---------------
Todas las figuras nuevas con leyendas numeradas conservan cuadros y números visibles.

REVISIÓN FINAL PENDIENTE
------------------------
Tras completar copias de seguridad y mantenimiento se auditarán todas las imágenes, especialmente Ventas.
