MANUAL WEB DE FACTURLINEX - EDICIÓN v0.3.1
==================================================

CONTENIDO
---------
- Manual web estático y responsive.
- Buscador instantáneo.
- Navegación por capítulos.
- Modo claro/oscuro.
- Menú moderno documentado visualmente.
- Ventas actualizadas con acceso Históricos y F1-F4 para aparcadas.
- Descargas integradas en DOCX y PDF.

INSTALACIÓN
-----------
1. Descomprima el paquete.
2. Copie la carpeta completa, por ejemplo, en:

   /var/www/html/manual-facturlinex/

3. Abra:

   https://su-dominio/manual-facturlinex/

No necesita PHP ni base de datos. También puede abrir index.html localmente.

DESCARGAS
---------
- descargas/Manual_FacturLinEx_v0.3.1_Correccion_Menu_y_Ventas.pdf
- descargas/Manual_FacturLinEx_v0.3.1_Correccion_Menu_y_Ventas.docx

NOVEDADES v0.3.1
----------------
- Sustituida la imagen del menú antiguo por reconstrucciones documentales basadas en la versión moderna actual.
- Incorporado el acceso Históricos al Histórico de operaciones realizadas.
- Diferenciados Histórico + filtro e Históricos.
- Eliminada la referencia a un resumen de cobro permanente.
- Documentadas F1, F2, F3 y F4 para las primeras cuatro ventas aparcadas.

NOTA VISUAL
-----------
Las imágenes corregidas del Menú y del nuevo botón Históricos se identifican como reconstrucciones o composiciones documentales. No se presentan como capturas directas posteriores a los últimos cambios.
