MANUAL WEB DE FACTURLINEX - EDICIÓN v0.3
================================================

CONTENIDO
---------
- Manual web estático y responsive.
- Buscador instantáneo.
- Navegación por capítulos.
- Modo claro/oscuro.
- Capítulos ilustrados: Menú principal y Ventas.
- Descargas integradas en DOCX y PDF.

INSTALACIÓN EN APACHE O NGINX
-----------------------------
1. Descomprima el paquete.
2. Copie la carpeta completa en el directorio publicado, por ejemplo:

   /var/www/html/manual-facturlinex/

3. Abra en el navegador:

   https://su-dominio/manual-facturlinex/

No necesita PHP, MariaDB ni procesos de instalación. También puede abrir index.html localmente.

ARCHIVOS DE DESCARGA
--------------------
- descargas/Manual_FacturLinEx_v0.3_Ilustrado_Menu_y_Ventas.pdf
- descargas/Manual_FacturLinEx_v0.3_Ilustrado_Menu_y_Ventas.docx

NOVEDAD v0.3
------------
Se ha ilustrado el capítulo del Menú principal con una captura real compatible, zonas numeradas, detalle de pestañas y módulos, accesos rápidos y barra de estado. Se mantiene íntegro el capítulo ilustrado de Ventas de la edición v0.2.

NOTA SOBRE LAS CAPTURAS
-----------------------
La pantalla del Menú principal se identifica como revisión real anterior compatible del 10/07/2026. La versión final aceptada puede mostrar diferencias visuales menores, pero conserva la navegación por pestañas y botones.
