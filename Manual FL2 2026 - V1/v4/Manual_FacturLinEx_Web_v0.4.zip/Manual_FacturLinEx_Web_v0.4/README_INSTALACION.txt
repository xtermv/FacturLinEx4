MANUAL WEB DE FACTURLINEX - EDICIÓN v0.4
================================================

CONTENIDO
---------
- Manual web estático y responsive.
- Buscador instantáneo.
- Navegación por capítulos.
- Modo claro/oscuro.
- Capítulos ilustrados: Menú principal, Configuración general y Ventas.
- Descargas integradas en DOCX y PDF.
- Capturas de configuración anonimizadas para publicación pública.

INSTALACIÓN EN APACHE O NGINX
-----------------------------
1. Descomprima el paquete.
2. Copie la carpeta completa en el directorio publicado, por ejemplo:

   /var/www/html/manual-facturlinex/

3. Abra en el navegador:

   https://su-dominio/manual-facturlinex/

No necesita PHP, MariaDB ni procesos de instalación. También puede abrir index.html localmente.

ARCHIVOS DE DESCARGA
--------------------
- descargas/Manual_FacturLinEx_v0.4_Configuracion_Ilustrada.pdf
- descargas/Manual_FacturLinEx_v0.4_Configuracion_Ilustrada.docx

NOVEDAD v0.4
------------
Se ha ampliado e ilustrado el capítulo de Configuración general con capturas reales de:
- Conexiones y prueba de BBDD.
- Tienda activa y puesto.
- Sistema de información común.
- Correo SMTP.
- Impresión, PDF y textos QR.
- Entorno de producción y rutas.
- Sistema de puntos.

SEGURIDAD DE LAS CAPTURAS
-------------------------
Los servidores, usuarios, correos y rutas personales visibles en las capturas se han sustituido por datos de ejemplo. No publique claves, direcciones internas ni credenciales reales.

ACTUALIZACIÓN
-------------
Para sustituir una versión anterior, copie el contenido completo de esta carpeta sobre la carpeta publicada y elimine los archivos antiguos que ya no se utilicen.
