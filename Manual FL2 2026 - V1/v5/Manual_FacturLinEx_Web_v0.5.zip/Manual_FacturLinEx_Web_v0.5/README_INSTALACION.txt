MANUAL WEB DE FACTURLINEX - EDICIÓN v0.5
================================================

CONTENIDO
---------
- Manual web estático y responsive.
- Buscador instantáneo.
- Navegación por capítulos.
- Modo claro/oscuro.
- Capítulos ilustrados: Menú principal, Configuración, Clientes y Ventas.
- Descargas integradas en DOCX y PDF.

INSTALACIÓN EN APACHE O NGINX
------------------------------
1. Descomprima el paquete.
2. Copie la carpeta completa en el directorio publicado, por ejemplo:

   /var/www/html/manual-facturlinex/

3. Abra en el navegador:

   https://su-dominio/manual-facturlinex/

No necesita PHP, MariaDB ni procesos de instalación. También puede abrir index.html localmente.

ARCHIVOS DE DESCARGA
--------------------
- descargas/Manual_FacturLinEx_v0.5_Clientes_Ilustrado.pdf
- descargas/Manual_FacturLinEx_v0.5_Clientes_Ilustrado.docx

NOVEDAD v0.5
------------
El capítulo de Clientes incorpora capturas reales con cuadros y números, explicación de la ficha general, facturación, rutas, puntos, coincidencias de NIF y cliente a precio de coste.

REVISIÓN VISUAL FINAL
---------------------
Cuando todos los capítulos estén ilustrados se revisará el manual completo para confirmar que cada número conserva su cuadro y su leyenda, especialmente en Ventas.
