MANUAL FACTURLINEX WEB v0.7
==============================

Manual estático responsive, sin PHP ni base de datos.

Capítulos ilustrados: Menú, Configuración, Clientes, Artículos, Ventas y Caja/Créditos.

INSTALACIÓN
Copie la carpeta en /var/www/html/manual-facturlinex/ y abra https://su-dominio/manual-facturlinex/

DESCARGAS
- descargas/Manual_FacturLinEx_v0.7_Caja_Cobros_Creditos_Ilustrado.pdf
- descargas/Manual_FacturLinEx_v0.7_Caja_Cobros_Creditos_Ilustrado.docx

NOVEDAD v0.7
Caja, cobros y créditos incorpora arqueo, pagos, ingresos, créditos, saldos, estado de cuenta e informes IVA. Todas las leyendas numeradas conservan cuadros visibles.

REVISIÓN FINAL PENDIENTE
Al terminar todos los capítulos se auditará el manual completo imagen por imagen, especialmente Ventas.
