MANUAL WEB DE FACTURLINEX - EDICIÓN v0.8
================================================

CONTENIDO
---------
- Manual web estático y responsive.
- Buscador instantáneo y navegación por capítulos.
- Modo claro/oscuro.
- Capítulos ilustrados del 1 al 7: Menú, Configuración, Clientes, Artículos, Ventas, Caja/Créditos y Compras/Pedidos/Existencias.
- Descargas integradas en DOCX y PDF.

INSTALACIÓN
-----------
Descomprima y copie la carpeta, por ejemplo, en:

   /var/www/html/manual-facturlinex/

Después abra https://su-dominio/manual-facturlinex/
No necesita PHP ni MariaDB y también funciona abriendo index.html localmente.

ARCHIVOS DE DESCARGA
--------------------
- descargas/Manual_FacturLinEx_v0.8_Compras_Pedidos_Existencias_Ilustrado.pdf
- descargas/Manual_FacturLinEx_v0.8_Compras_Pedidos_Existencias_Ilustrado.docx

NOVEDAD v0.8
------------
Compras, pedidos y existencias incorpora el flujo completo de compra, Pedido automático por proveedor, parámetros y modos de cálculo, confianza, similares, selección múltiple, borradores, historial anti-duplicado, creación de pedido real, PDF/CSV, recepción de mercancía y actualización de stock.

CRITERIO VISUAL
---------------
Todas las figuras nuevas con leyendas numeradas conservan cuadros y números visibles sobre la propia imagen.

REVISIÓN FINAL PENDIENTE
------------------------
Al terminar todos los capítulos se revisará el manual completo imagen por imagen, especialmente Ventas, para comprobar que cada número referencia un cuadro visible y una leyenda correcta.
