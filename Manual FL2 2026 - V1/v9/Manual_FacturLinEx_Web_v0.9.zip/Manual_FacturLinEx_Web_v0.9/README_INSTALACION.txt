MANUAL WEB DE FACTURLINEX - EDICIÓN v0.9
================================================

CONTENIDO
---------
- Manual web estático, responsive y con buscador.
- Modo claro/oscuro.
- Capítulos ilustrados del 1 al 8.
- Descargas integradas en DOCX y PDF.

INSTALACIÓN
-----------
Copie la carpeta, por ejemplo, en /var/www/html/manual-facturlinex/ y abra su URL.
No necesita PHP ni MariaDB y también funciona abriendo index.html localmente.

ARCHIVOS
--------
- descargas/Manual_FacturLinEx_v0.9_Facturacion_Impresion_PDF_Correo_Ilustrado.pdf
- descargas/Manual_FacturLinEx_v0.9_Facturacion_Impresion_PDF_Correo_Ilustrado.docx

NOVEDAD v0.9
------------
Facturación, impresión, PDF y correo incorpora facturación de albaranes, serie/fecha/observaciones, progreso seguro, factura PDF con Dto., previsualización, impresión, envío SMTP, recibos y diagnóstico de plantillas .lrf.

CRITERIO VISUAL
---------------
Todas las figuras nuevas con leyendas numeradas conservan cuadros y números visibles.

REVISIÓN FINAL PENDIENTE
------------------------
Al terminar los capítulos restantes se auditarán todas las imágenes, especialmente Ventas.
